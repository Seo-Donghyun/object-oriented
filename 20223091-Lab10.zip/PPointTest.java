/**
	@author : Seo-Donghyun
	student_ID : 20223091
*/
import kr.ac.kookmin.cs.*;

/**
	This class tests the PPoint class
*/
class PPointTest {
	/**
		this method tests the getter method of the PPoint class
		by giving it 10 and 20
		@param args String list
	*/
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}
