/**
	package name : kr.ac.kookmin.cs
	@author Seo-Donghyun
	student_ID : 20223091
*/
package kr.ac.kookmin.cs;

/**
	This class takes two arguments,
	stores each argument in a parameter,
	and has a getter method for that parameter.
*/
public class PPoint {
    int xA;
    int yA;
	/**
		object constructor(PPoint)
		@param x first integers
		@param y second integers
	*/
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
	
	/**
		@return : xA
	*/
    public int getX() {
        return xA;
    }
	
	/**
		@return : yA
	*/
    public int getY() {
        return yA;
    }
}
