// ****************************************************************
// Factorials.java
//
// Reads integers from the user and prints the factorial of each.
//          
// ****************************************************************

import java.util.Scanner;

public class Factorials {
    public static void main(String[] args) {
	Scanner in = new Scanner(System.in); // scanner를 하나 만들었습니다.
	char keepGoing = 'y';
	while (keepGoing == 'y' || keepGoing == 'Y') {
	    System.out.print("Enter an integer: ");
	    int val = in.nextInt();
	    try {
		System.out.println("Factorial(" + val + ") = " + MathUtils.factorial(val));
		System.out.print("Another factorial? (y/n) ");
		keepGoing = in.next().charAt(0);
	    } catch (IllegalArgumentException e) {
		System.out.println(e.getMessage());
		continue;
	    }
	}

	in.close();
    }
}
