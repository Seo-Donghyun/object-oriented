import java.io.*;
import java.util.StringTokenizer;

public class UseBufferedReader {

    public static void main(String[] args) throws IOException {
	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

	System.out.println("write something or quit");
	String s = in.readLine();
	while (!s.equals("quit")) {
	    try {
		System.out.println(s);
		StringTokenizer tk = new StringTokenizer(s);
		int token = tk.countTokens();
		while (tk.hasMoreTokens()) {
		    System.out.println(tk.nextToken());
		}
		System.out.printf("There are %d words in the line.\n", token);
		s = in.readLine();
	    } catch (IOException e) {
		System.out.println(e.getMessage());
	    }

	}
	in.close();

    }

}
