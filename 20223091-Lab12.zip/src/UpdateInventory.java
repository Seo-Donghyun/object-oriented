// **********************************************************************************
//   UpdateInventory.java        Author: Lewis/Loftus (with modification)
//
//   Demonstrates the use of character file I/O.
// **********************************************************************************

import java.io.*;
import java.util.StringTokenizer;

public class UpdateInventory {
    // -------------------------------------------------------------------
    // Reads data about a store inventory from an input file, creating
    // an array of InventoryItem objects. For each inventory item, gets
    // the number of additional units and updates the total units
    // available (restocks), then writes the updated inventory back to
    // the file.
    // -------------------------------------------------------------------
    public static void main(String[] args) {
	final int MAX = 100;
	InventoryItem[] items = new InventoryItem[MAX];
	StringTokenizer tokenizer;
	// 교수님 실습문제 밑에 코드를 복사해서 사용했는데, 그렇게 하니까 inventory.dat를 못 찾는경우가 생겨서
	// inventory.dat -> src/inventory.dat로 바꾸었습니다.
	String line, name, file = "src/inventory.dat";
	int units, count = 0;
	int addedUnits;
	float price;

	try {
	    FileReader fr = new FileReader(file);
	    // 원래 BufferedReader inFile = new BufferedReader(fr);
	    BufferedReader inFile = new BufferedReader(fr);

	    line = inFile.readLine();
	    while (line != null) {
		tokenizer = new StringTokenizer(line);
		name = tokenizer.nextToken();
		try {
		    units = Integer.parseInt(tokenizer.nextToken());
		    price = Float.parseFloat(tokenizer.nextToken());
		    items[count++] = new InventoryItem(name, units, price);
		} catch (NumberFormatException exception) {
		    System.out.println("Error in input. Line ignored.");
		    System.out.println(line);
		}
		line = inFile.readLine();
	    }
	    inFile.close();

	    System.out.println("\nEnter the number of additional units of each item: ");

	    // Set up the output file stream
	    FileWriter fw = new FileWriter(file);
	    BufferedWriter bw = new BufferedWriter(fw);
	    PrintWriter outFile = new PrintWriter(bw);

	    for (int scan = 0; scan < count; scan++) {
		BufferedReader addnum = new BufferedReader(new InputStreamReader(System.in));
		System.out.println(items[scan].getName() + " How many would you like to add?");
		String num = addnum.readLine();
		addedUnits = Integer.parseInt(num);
		items[scan].restock(addedUnits);
		outFile.print(items[scan].getName() + " " + items[scan].getUnits() + " " + items[scan].getPrice());
		outFile.println();
		System.out.println(items[scan]);
	    }

	    // Close the output file stream
	    outFile.close();

	} catch (FileNotFoundException exception) {
	    System.out.println("The file " + file + " was not found.");
	} catch (IOException exception) {
	    System.out.println(exception);
	}
    }
}
