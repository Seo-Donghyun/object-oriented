// ****************************************************************
// MathUtils.java
//
// Provides static mathematical utility functions.
//          
// ****************************************************************

public class MathUtils {
    // -------------------------------------------------------------
    // Returns the factorial of the argument given
    // -------------------------------------------------------------
    public static int factorial(int n) throws IllegalArgumentException {
	if (n < 0) {
	    throw new IllegalArgumentException("the argument is less than zero.");
//	    return IllegalArgumentException.toString();
	} else if (n >= 17) {
	    throw new IllegalArgumentException("please write argument less than 17");
	}

	int fac = 1;
	for (int i = n; i > 0; i--)
	    fac *= i;
	return fac;
    }

}
